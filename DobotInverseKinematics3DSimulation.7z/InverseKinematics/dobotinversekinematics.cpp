#include "dobotinversekinematics.h"




using namespace std;

double get_lengthUpperArm(){

    return 135;
}

double get_lengthLowerArm(){
    return 160;
}

double get_heightFromBase(){
    return 80;
}


/*
#input:
#cartesian (x,y,z) coordinate
#robot dimensions
#output:
#angles for robot arm base, upper, and lower arms in degree
*/
std::vector<double> convert_cartesian_coordinate_to_arm_angles(double x, double y, double z, double upperArmLength, double lowerArmLength, double baseHeight){
/*
    #do a general check to see if even a maximally stretched arm could reach the point
    # if it can't, return some dummy angle numbers of -999
    #note the base height correction in z
    */
    double distanceFromOriginToEndPoint = get_distance_from_origin_to_cartesian_point_3D(x,y,z-baseHeight);
    //print(str(distanceFromOriginToEndPoint))
    if (distanceFromOriginToEndPoint > (upperArmLength + lowerArmLength)){
        vector<double> v {-999,-999,-999};
        return v;
    }

    double baseAngle = get_polar_coordinate_angle_from_cartesian_x_y_coordinate(x,y);
    double radiusToEndPoint = get_polar_coordinate_radius_from_cartesian_x_y_coordinate(x,y);
    //note the correction for base height
    vector<double> armAngles;
    armAngles = get_arm_angles_from_radius_z_coordinate_using_2d_revolute_revolute_inverse_kinematics(radiusToEndPoint, z-baseHeight, upperArmLength, lowerArmLength);
    double upperArmAngle = armAngles[0];
    double lowerArmAngle = armAngles[1];

    //convert the angles to degrees when you return them
    vector<double> returnvec {baseAngle * (180/M_PI) , upperArmAngle * (180/M_PI), lowerArmAngle * (180/M_PI)};
    return returnvec;
}


std::vector<double> get_arm_angles_from_radius_z_coordinate_using_2d_revolute_revolute_inverse_kinematics(double r, double z, double upperArmLength, double lowerArmLength){

   // #eq is a dummy variable for the equation that it represents
    double eq = ( pow(upperArmLength,2) + pow(lowerArmLength,2) - pow(r,2) - pow(z,2) ) / ( 2 * upperArmLength * lowerArmLength );
/*
    #the two angles are due to the two possible angles, elbow up or down. I always want elbow up.
    #Not sure which one is elbow up, guessing it's the positive sqrt equation for now. CHECK THIS!
    //note that pi radians = 180 degrees*/
    double lowerArmAngle = M_PI - atan2( sqrt(1 - pow(eq,2)), eq );
    //including the angle two
    double lowerArmAngleAlternative = M_PI - atan2( -1 * sqrt(1 - pow(eq,2)), eq );
    lowerArmAngle = lowerArmAngleAlternative;


/*
    #note that the upperArmAngle is dependent on the lowerArmAngle. This makes sense.
    # can easily envision that upper arm would be at two different angles if arm is elbow up or down
            */
    double upperArmAngle = atan2(z,r) - atan2( (lowerArmLength * sin(lowerArmAngle)) , (upperArmLength + (lowerArmLength * cos(lowerArmAngle))) );

    vector<double> returnvec {upperArmAngle, lowerArmAngle};
    return returnvec;
}



/*
#input:
#x,y coordinate
#output
#polar coordinate angle to x,y point in radians
*/
double get_polar_coordinate_angle_from_cartesian_x_y_coordinate(double x,double y){
    /*
    #use cartesian to polar conversion equations to get the angle
    #alternatively, this is just using the toa rule
    */
    double angle = atan2(y,x);
    return angle;
}

/*
#input:
#x,y coordinate
#output
#length of polar coordinate radius to x,y point
*/
double get_polar_coordinate_radius_from_cartesian_x_y_coordinate(double x,double y){
    /*
    #use cartesian to polar conversion equations to get the angle
    #alternatively, this is just using the circle equation rule
    */
    double radius = sqrt(pow(x,2) + pow(y,2));
    return radius;
}

double get_distance_from_origin_to_cartesian_point_3D(double x, double y, double z){
    //#get distance from origin (0,0,0) to end point in 3D using pythagorean thm in 3D; distance = sqrt(x^2+y^2+z^2)
    double distanceToEndPoint = sqrt( pow(x,2) + pow(y,2) + pow(z,2) );
    //print(distanceToEndPoint)
    return distanceToEndPoint;
}

/*
def get_upper_arm_angle():
    #return the angle in degrees or radians for the upper arm from the accelerometer data and/or known theoretical angle
    return 45#or radians!

def get_lower_arm_angle():
    #return the angle in degrees or radians for the lower arm from the accelerometer data and/or known theoretical angle
    return 45#or radians!

def get_base_angle():
    #return the angle in degrees or radians for the base from the accelerometer data and/or known theoretical angle
    return 45#or radians!


"""

    #get polar coordinates for the current point
    #radius is simply given by the base angle
    # can read the angles from the IMU and empirically determine the radius and angle - I'm using this approach since it should account for any build up in error, assuming accelerometers
    #are accurate!!!!
    #alternatively can just use pythagorean thm on theoretical current x,y data

    startUpperArmAngle = get_upper_arm_angle
    startLowerArmAngle = get_lower_arm_angle
    startBaseAngle = get_base_angle

    #could abstract this next bit into a 2D forward kinematics function and then just use the horizontal data returned
    #only care about the radius, so


    currentPosPolarCoordRadius = ???
    currentPosPolarCoordAngle = currentBaseAngle


    #end get polar coordinates


def get_radius_in_horizontal_plane_to_cartesian_end_effector_position_using_2d_revolute_revolute_forward_kinematics(upperArmAngle, lowerArmAngle, upperArmLength, lowerArmLength):
    #the equation for radius is determined using forward kinematics, just uses socahtoa rules, namely coa here.
    radius = ( math.cos(upperArmAngle) * upperArmLength ) + ( math.cos(upperArmAngle + lowerArmAngle) * lowerArmLength )
    return radius








"""


if __name__ == '__main__':



    # length and height dimensions in mm
    lengthUpperArm = 135
    lengthLowerArm = 160
    heightFromBase = 80

    commandFlag = True
    while(commandFlag):
        x = input('Enter x: ')
        y = input('Enter y: ')
        z = input('Enter z: ')
        angles = convert_cartesian_coordinate_to_arm_angles(double(x),double(y),double(z),lengthUpperArm,lengthLowerArm,heightFromBase)

        if(angles[0] != -999):
            print('\nFor the point (' + str(x) + ' , ' + str(y) + ' , ' + str(z) + ') , the angles are:' )
            print('Base Angle: ' + str(angles[0]) )
            print('Upper Arm Angle: ' + str(angles[1]) )
            print('Lower Arm Angle: ' + str(angles[2]))
            print('\n')
        else:
            print('Invalid coordinate: Out of arm\'s range.')
            print('\n')

        s = input('quit?')
        if (s == 'y'):
            commandFlag = False
        print('\n')

*/
