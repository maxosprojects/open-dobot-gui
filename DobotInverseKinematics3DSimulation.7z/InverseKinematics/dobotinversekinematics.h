#ifndef DOBOTINVERSEKINEMATICS_H
#define DOBOTINVERSEKINEMATICS_H


#include <math.h>
#include <vector>

#define M_PI           3.14159265358979323846

//length and height dimensions in mm
extern double lengthUpperArm;
extern double lengthLowerArm;
extern double heightFromBase;

double get_lengthUpperArm();
double get_lengthLowerArm();
double get_heightFromBase();

std::vector<double> convert_cartesian_coordinate_to_arm_angles(double x, double y, double z, double upperArmLength, double lowerArmLength, double baseHeight);
std::vector<double> get_arm_angles_from_radius_z_coordinate_using_2d_revolute_revolute_inverse_kinematics(double r, double z, double upperArmLength, double lowerArmLength);
double get_polar_coordinate_angle_from_cartesian_x_y_coordinate(double x,double y);
double get_polar_coordinate_radius_from_cartesian_x_y_coordinate(double x,double y);
double get_distance_from_origin_to_cartesian_point_3D(double x, double y, double z);

#endif // DOBOTINVERSEKINEMATICS_H
