/****************************************************************************
**
** Copyright (C) 2014 Klaralvdalens Datakonsult AB (KDAB).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the Qt3D module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL3$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see http://www.qt.io/terms-conditions. For further
** information use the contact form at http://www.qt.io/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 3 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPLv3 included in the
** packaging of this file. Please review the following information to
** ensure the GNU Lesser General Public License version 3 requirements
** will be met: https://www.gnu.org/licenses/lgpl.html.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 2.0 or later as published by the Free
** Software Foundation and appearing in the file LICENSE.GPL included in
** the packaging of this file. Please review the following information to
** ensure the GNU General Public License version 2.0 requirements will be
** met: http://www.gnu.org/licenses/gpl-2.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "scenemodifier.h"

#include <QtCore/QDebug>

const float PI = 3.14159265359;

SceneModifier::SceneModifier(Qt3D::QEntity *rootEntity)
    : m_rootEntity(rootEntity)
{

    // Torus shape data
    //! [0]
    m_torus = new Qt3D::QTorusMesh();
    m_torus->setRadius(1.0f);
    m_torus->setMinorRadius(0.4f);
    m_torus->setRings(100);
    m_torus->setSlices(20);
    //! [0]

    // TorusMesh Transform
    //! [1]
    Qt3D::QScaleTransform *torusScale = new Qt3D::QScaleTransform();
    Qt3D::QTranslateTransform *torusTranslation = new Qt3D::QTranslateTransform();
    Qt3D::QRotateTransform *torusRotation = new Qt3D::QRotateTransform();
    Qt3D::QTransform *torusTransforms = new Qt3D::QTransform();

    torusScale->setScale3D(QVector3D(1.0f, 1.0f, 1.0f));
    torusTranslation->setTranslation(QVector3D(0.0f, 0.0f, 0.0f));


    torusRotation->setAngleDeg(0.0f);
    torusRotation->setAxis(QVector3D(0, 1, 0));

    torusTransforms->addTransform(torusRotation);
    torusTransforms->addTransform(torusTranslation);
    torusTransforms->addTransform(torusScale);
    //! [1]

    //! [2]
    Qt3D::QPhongMaterial *torusMaterial = new Qt3D::QPhongMaterial();
    torusMaterial->setDiffuse(QColor(QRgb(0xbeb32b)));
    //! [2]

    // Torus
    //! [3]
    m_baseEntity = new Qt3D::QEntity(m_rootEntity);
    m_baseEntity->addComponent(m_torus);
    m_baseEntity->addComponent(torusMaterial);
    m_baseEntity->addComponent(torusTransforms);
    //! [3]







//UpperArm
    // Cylinder shape data
    Qt3D::QCylinderMesh *cylinder = new Qt3D::QCylinderMesh();
    cylinder->setRadius(.3);
    cylinder->setLength(upperArmLength);
    cylinder->setRings(100);
    cylinder->setSlices(20);

    // CylinderMesh Transform
    Qt3D::QScaleTransform *cylinderScale = new Qt3D::QScaleTransform();
    Qt3D::QRotateTransform *cylinderRotation = new Qt3D::QRotateTransform();
    Qt3D::QTranslateTransform *cylinderTranslation = new Qt3D::QTranslateTransform();
    Qt3D::QTransform *cylinderTransforms = new Qt3D::QTransform();

    cylinderScale->setScale3D(QVector3D(1.0f, 1.0f, 1.0f));
    cylinderTranslation->setTranslation(QVector3D(0.0f, (float)(upperArmLength/2), 0.0f));
    cylinderRotation->setAngleDeg(upperArmAngle);
    cylinderRotation->setAxis(QVector3D(0, 0, 1));


    // addTransform order matters !!!
    cylinderTransforms->addTransform(cylinderTranslation);
    cylinderTransforms->addTransform(cylinderRotation);
    cylinderTransforms->addTransform(cylinderScale);

    Qt3D::QPhongMaterial *cylinderMaterial = new Qt3D::QPhongMaterial();
    cylinderMaterial->setDiffuse(QColor(QRgb(0x928327)));

    // Cylinder
    m_upperArmEntity = new Qt3D::QEntity(m_rootEntity);
    m_upperArmEntity->addComponent(cylinder);
    m_upperArmEntity->addComponent(cylinderMaterial);
    m_upperArmEntity->addComponent(cylinderTransforms);










    //foreArm
        // Cylinder shape data
        Qt3D::QCylinderMesh *cylinder2 = new Qt3D::QCylinderMesh();
        cylinder2->setRadius(.3);
        cylinder2->setLength(foreArmLength);
        cylinder2->setRings(100);
        cylinder2->setSlices(20);

        // CylinderMesh Transform
        Qt3D::QScaleTransform *cylinder2Scale = new Qt3D::QScaleTransform();
        Qt3D::QRotateTransform *cylinder2Rotation = new Qt3D::QRotateTransform();
        Qt3D::QTranslateTransform *cylinder2Translation = new Qt3D::QTranslateTransform();
        foreArmTransforms = new Qt3D::QTransform();

        cylinder2Scale->setScale3D(QVector3D(1.0f, 1.0f, 1.0f));

        float x = -sin(45.0 * (PI/180.0)) * 5;//45 is the degrees of the upperArm, 5 is the length
        float y = cos(45.0 * (PI/180.0)) * 5;//45 is the degrees of the upperArm, 5 is the length

        cylinder2Translation->setTranslation(QVector3D(0, (float)(cylinder2->length() / 2) , 0.0));
        foreArmAngle = 135.0f;
        cylinder2Rotation->setAngleDeg(135.0f);
        cylinder2Rotation->setAxis(QVector3D(0, 0, 1));


        Qt3D::QTranslateTransform *cylinder2Translation2 = new Qt3D::QTranslateTransform();
        cylinder2Translation2->setTranslation(QVector3D(x, y , 0.0));


        // addTransform order matters !!!
        foreArmTransforms->addTransform(cylinder2Translation);
        foreArmTransforms->addTransform(cylinder2Rotation);
          foreArmTransforms->addTransform(cylinder2Translation2);




        foreArmTransforms->addTransform(cylinder2Scale);




        Qt3D::QPhongMaterial *cylinder2Material = new Qt3D::QPhongMaterial();
        cylinder2Material->setDiffuse(QColor(QRgb(0x928327)));

        // Cylinder
        m_foreArmEntity = new Qt3D::QEntity(m_rootEntity);
        m_foreArmEntity->addComponent(cylinder2);
        m_foreArmEntity->addComponent(cylinder2Material);
        m_foreArmEntity->addComponent(foreArmTransforms);


}

SceneModifier::~SceneModifier()
{
}





void SceneModifier::rotateBase(){

/*
    Qt3D::QRotateTransform *torusRotation = new Qt3D::QRotateTransform();
    Qt3D::QTransform *torusTransforms = new Qt3D::QTransform();

    angle += 5.0f;
    torusRotation->setAngleDeg(angle);
   // torusRotation->setAxis(QVector3D(0, 1, 0));

    torusTransforms->addTransform(torusRotation);
*/



    Qt3D::QScaleTransform *torusScale = new Qt3D::QScaleTransform();
    Qt3D::QTranslateTransform *torusTranslation = new Qt3D::QTranslateTransform();
    Qt3D::QRotateTransform *torusRotation = new Qt3D::QRotateTransform();
    Qt3D::QTransform *torusTransforms = new Qt3D::QTransform();

    torusScale->setScale3D(QVector3D(1.0f, 1.0f, 1.0f));
    torusTranslation->setTranslation(QVector3D(0.0f, 0.0f, 0.0f));

    //angle += 5.0f;
    torusRotation->setAngleDeg(baseAngle);

    torusRotation->setAxis(QVector3D(0, 1, 0));

    torusTransforms->addTransform(torusRotation);
    torusTransforms->addTransform(torusTranslation);
    torusTransforms->addTransform(torusScale);


    m_baseEntity ->addComponent(torusTransforms);



}




void SceneModifier::rotateUpperArm(){

    //float oldAngle = upperArmAngle;

   // upperArmAngle = angle;

    // CylinderMesh Transform
    Qt3D::QScaleTransform *cylinderScale = new Qt3D::QScaleTransform();
    Qt3D::QRotateTransform *cylinderRotation = new Qt3D::QRotateTransform();
    Qt3D::QTranslateTransform *cylinderTranslation = new Qt3D::QTranslateTransform();
    Qt3D::QTransform *cylinderTransforms = new Qt3D::QTransform();

    cylinderScale->setScale3D(QVector3D(1.0f, 1.0f, 1.0f));
    cylinderTranslation->setTranslation(QVector3D(0.0f, (float)(upperArmLength/2), 0.0f));
    cylinderRotation->setAngleDeg(upperArmAngle);
    cylinderRotation->setAxis(QVector3D(0, 0, 1));


    // addTransform order matters !!!
    cylinderTransforms->addTransform(cylinderTranslation);
    cylinderTransforms->addTransform(cylinderRotation);
    cylinderTransforms->addTransform(cylinderScale);


    Qt3D::QRotateTransform *cylinderRotation2 = new Qt3D::QRotateTransform();
    cylinderRotation2->setAngleDeg(baseAngle);
    cylinderRotation2->setAxis(QVector3D(0, 1, 0));
    cylinderTransforms->addTransform(cylinderRotation2);

    m_upperArmEntity->addComponent(cylinderTransforms);


  // rotateElbow((upperArmAngle - oldAngle) + foreArmAngle );



}










void SceneModifier::rotateForeArm(){

   // float oldAngle = foreArmAngle;
    //foreArmAngle = angle;

//foreArmAngle += 5.0f;

// CylinderMesh Transform
Qt3D::QScaleTransform *cylinder2Scale = new Qt3D::QScaleTransform();
Qt3D::QRotateTransform *cylinder2Rotation = new Qt3D::QRotateTransform();
Qt3D::QTranslateTransform *cylinder2Translation = new Qt3D::QTranslateTransform();
foreArmTransforms = new Qt3D::QTransform();

cylinder2Scale->setScale3D(QVector3D(1.0f, 1.0f, 1.0f));

float x = -sin(upperArmAngle * (PI/180.0)) * upperArmLength;//45 is the degrees of the upperArm, 5 is the length
float y = cos(upperArmAngle * (PI/180.0)) * upperArmLength;//45 is the degrees of the upperArm, 5 is the length

cylinder2Translation->setTranslation(QVector3D(0, (float)(foreArmLength/2) , 0.0));

cylinder2Rotation->setAngleDeg(foreArmAngle);
cylinder2Rotation->setAxis(QVector3D(0, 0, 1));


Qt3D::QTranslateTransform *cylinder2Translation2 = new Qt3D::QTranslateTransform();
cylinder2Translation2->setTranslation(QVector3D(x, y , 0.0));


// addTransform order matters !!!
foreArmTransforms->addTransform(cylinder2Translation);
foreArmTransforms->addTransform(cylinder2Rotation);
  foreArmTransforms->addTransform(cylinder2Translation2);
foreArmTransforms->addTransform(cylinder2Scale);



Qt3D::QRotateTransform *cylinderRotation2 = new Qt3D::QRotateTransform();
cylinderRotation2->setAngleDeg(baseAngle);
cylinderRotation2->setAxis(QVector3D(0, 1, 0));
foreArmTransforms->addTransform(cylinderRotation2);



   m_foreArmEntity->addComponent(foreArmTransforms);


}












 void SceneModifier::updateArmPosition(float baseAngle, float upperArmAngle, float foreArmAngle){

     this->baseAngle = baseAngle;
     this->upperArmAngle = upperArmAngle;
     this->foreArmAngle = foreArmAngle;

     rotateBase();
     rotateUpperArm();
     rotateForeArm();

 }





