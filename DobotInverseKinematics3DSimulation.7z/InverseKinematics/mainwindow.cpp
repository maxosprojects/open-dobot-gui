#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonCalcAngles_clicked()
{


    updateArmPositionFromCartesian();

}



void MainWindow::updateArmPositionFromCartesian(){

    double x = ui->lineEditX->text().toDouble();
    double y = ui->lineEditY->text().toDouble();
    double z = ui->lineEditZ->text().toDouble();

    vector<double> angles = convert_cartesian_coordinate_to_arm_angles(x,y,z,get_lengthUpperArm(),get_lengthLowerArm(),get_heightFromBase());

    baseAngle = angles[0];
    upperArmAngle = angles[1];
    lowerArmAngle = angles[2];

    //vector<double> angles = cart

    //baseAngle


    /*

    if (x == 0.0f && y == 0.0f && z == 0.0f){
        qDebug() << "0,0,0 is impossible point" << endl;
        return;
    }


    if ( x > 0){
        y *= -1.0f;
    }

    if(y < 0  && x > 0){
        x *= -1.0f;


    }
    else if (y < 0 && x < 0){
        x *= -1.0f;
    }


//note that the order/sign of each dimension corrects for the mismatch in coordinate system orientation between ik.cpp and the 3d viewer
    if (solve(-z, y, x, baseAngle, upperArmAngle, foreArmAngle)) {

        //convert the radian values to degrees
        baseAngle = ( baseAngle / (2*PI) ) * 360;
        upperArmAngle = ( upperArmAngle / (2*PI) ) * 360;
        foreArmAngle = ( foreArmAngle /(2*PI) ) * 360;

        //correct for ik.cpp flipping artifact when changing between positive and negative dimensions
        if( x > 0){
            upperArmAngle = 180 - upperArmAngle ;
            foreArmAngle = 180 - foreArmAngle;
        }

        if( y < 0){
            //upperArmAngle = 2 * upperArmAngle;
            //foreArmAngle = 360 + foreArmAngle;
        }
        */





        //QString::number( x, 'd', 3 ) means print the double ('d') variable x to 3 digits after decimal precision
       qDebug() << "Cartesian Point: (" << QString::number( x, 'd', 5 ) << ", "
                <<  QString::number( y, 'd', 5 ) << ", " <<  QString::number( z, 'd', 5 ) << ") in base, upper, lower angles is: "
       << QString::number( baseAngle, 'd', 5 ) << ", " <<  QString::number( upperArmAngle, 'd', 5 ) << ", "
       <<  QString::number( lowerArmAngle, 'd', 5 ) << endl;


       double transformedUpperArmAngle = (-1 * upperArmAngle) + 90;
       double transformedLowerArmAngle = 360 + (transformedUpperArmAngle + ((lowerArmAngle)*-1));
       qDebug() <<"transformedUpperArmAngle: " << QString::number( transformedUpperArmAngle, 'd', 5 ) <<
                   endl << "transformedLowerArmAngle" << QString::number( transformedLowerArmAngle, 'd', 5 ) << endl;

       this->modifier->updateArmPosition(baseAngle, transformedUpperArmAngle, transformedLowerArmAngle);

/*
    }
    else{
        qDebug() << "Not a valid point? Not within range?" << endl;
    }
*/

}

void MainWindow::updateArmPositionFromAngles(){

     baseAngle = ui->lineEditBaseAngle->text().toDouble();
    upperArmAngle = ui->lineEditUpperArmAngle->text().toDouble();
    lowerArmAngle = ui->lineEditForeArmAngle->text().toDouble();

    this->modifier->updateArmPosition(baseAngle, upperArmAngle, lowerArmAngle+90);
}


void MainWindow::on_xSlider_valueChanged(int value)
{
    ui->lineEditX->setText(QString::number( value, 'd', 5 ));
    updateArmPositionFromCartesian();
}

void MainWindow::on_ySlider_valueChanged(int value)
{
    ui->lineEditY->setText(QString::number( value, 'd', 5 ));
    updateArmPositionFromCartesian();
}

void MainWindow::on_zSlider_valueChanged(int value)
{
    ui->lineEditZ->setText(QString::number( value, 'd', 5 ));
    updateArmPositionFromCartesian();
}

void MainWindow::on_baseAngleSlider_valueChanged(int value)
{
    ui->lineEditBaseAngle->setText(QString::number( value, 'd', 5 ));
    updateArmPositionFromAngles();
}

void MainWindow::on_upperArmAngleSlider_valueChanged(int value)
{
    ui->lineEditUpperArmAngle->setText(QString::number( value, 'd', 5 ));
    updateArmPositionFromAngles();
}

void MainWindow::on_foreArmAngleSlider_valueChanged(int value)
{
    ui->lineEditForeArmAngle->setText(QString::number( value, 'd', 5 ));
    updateArmPositionFromAngles();
}
